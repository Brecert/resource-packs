Only Wand files should be in this folder.
-----------------------------------------
A Wand files name format is;
� dmgvaluenumber_wand_name-type.
� Eg. 5_wand_mushroom-model.json or 5_wand_mushroom-setup.json
---
To get the override damage value for the model, simply
� Divide by 1/32 (or the number of damage values the item has)
� Take that number and then multiply it by what slot you want.
� Eg. 1/32 = 0.03125, 0.03125 * 5 = 0.15625
---
_wand_display is a template, for what should be used for the display tags at the bottom of the model files
- Brecert
